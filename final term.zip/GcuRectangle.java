
import java.awt.Color;
import java.awt.Graphics;

public class GcuRectangle extends GcuBoundedShape
{ 
    public GcuRectangle() {
        super();
    }

    public GcuRectangle(int startX, int startY, int endX, int endY, Color color, boolean fill) {
        super(startX, startY, endX, endY, color, fill);
    }
    
    @Override
    public void draw( Graphics g ) {
        g.setColor(getColor());
        if(isFilled()){
            g.fillRect(getUpperLeftS(),getUpperLeftY(),getWidth(),getHeight());
        }
        else{
            g.drawRect(getUpperLeftS(),getUpperLeftY(),getWidth(),getHeight());
        }
		
		
    }
}
